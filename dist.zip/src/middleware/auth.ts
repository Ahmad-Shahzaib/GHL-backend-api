import { Request, Response, NextFunction } from 'express';
import { authService } from '../services/authService';
import { ghlClient } from '../services/ghlClient';
import { tokenStore } from '../services/tokenStore';
import { Errors, APIError } from './errorHandler';
import { JWTPayload, AuthUser } from '../types';

// Extend Express Request type to include user
declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
      tokenPayload?: JWTPayload;
    }
  }
}

/**
 * JWT Authentication middleware
 * Verifies the Bearer token from Authorization header
 */
export const authenticate = async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw Errors.Unauthorized('Authorization header missing or invalid');
    }
    
    const token = authHeader.substring(7); // Remove 'Bearer ' prefix
    
    if (!token) {
      throw Errors.Unauthorized('Token not provided');
    }
    
    // Verify JWT
    const payload = authService.verifyToken(token);
    
    // Check if GHL tokens are still valid
    const tokenKey = payload.locationId || payload.userId;
    const hasValidTokens = await tokenStore.hasValidTokens(tokenKey);
    
    if (!hasValidTokens) {
      // Try to refresh
      const refreshed = await authService.ensureValidGHLToken(tokenKey);
      if (!refreshed) {
        throw Errors.Unauthorized('Session expired. Please reconnect your GoHighLevel account.');
      }
    }
    
    // Set user info on request
    req.tokenPayload = payload;
    req.user = {
      id: payload.userId,
      email: payload.email,
      locationId: payload.locationId,
      companyId: payload.companyId,
      permissions: [], // Would be populated from stored permissions
    };
    
    // Set GHL client token key for subsequent API calls
    ghlClient.setTokenKey(tokenKey);
    
    next();
  } catch (error) {
    if (error instanceof APIError) {
      next(error);
    } else {
      next(Errors.Unauthorized('Authentication failed'));
    }
  }
};

/**
 * Optional authentication middleware
 * Sets user info if token is present, but doesn't require it
 */
export const optionalAuth = async (req: Request, _res: Response, next: NextFunction): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return next();
    }
    
    const token = authHeader.substring(7);
    
    if (!token) {
      return next();
    }
    
    // Verify JWT
    const payload = authService.verifyToken(token);
    
    // Set user info on request
    req.tokenPayload = payload;
    req.user = {
      id: payload.userId,
      email: payload.email,
      locationId: payload.locationId,
      companyId: payload.companyId,
      permissions: [],
    };
    
    // Set GHL client token key
    const tokenKey = payload.locationId || payload.userId;
    ghlClient.setTokenKey(tokenKey);
    
    next();
  } catch (error) {
    // Don't throw error for optional auth, just continue without user
    next();
  }
};

/**
 * Permission check middleware factory
 */
export const requirePermission = (...requiredPermissions: string[]) => {
  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.user) {
      next(Errors.Unauthorized('Authentication required'));
      return;
    }
    
    const hasPermission = requiredPermissions.every(permission => 
      authService.hasPermission(req.user!.permissions, permission)
    );
    
    if (!hasPermission) {
      next(Errors.Forbidden('Insufficient permissions'));
      return;
    }
    
    next();
  };
};

/**
 * Role-based access control middleware
 */
export const requireRole = (..._allowedRoles: string[]) => {
  return (req: Request, _res: Response, next: NextFunction): void => {
    if (!req.user) {
      next(Errors.Unauthorized('Authentication required'));
      return;
    }
    
    // This would check user roles from your database
    // For now, we'll assume all authenticated users have basic access
    next();
  };
};
